from distutils.core import setup

setup(name="DimA",version="0.1",packages=["DimA",],license="Open Source",long_description=open("README.txt").read())
